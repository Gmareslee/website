const navItems = document.querySelectorAll('.admin-nav');
const views = document.querySelectorAll('.admin-view');
const viewTitle = document.getElementById('view-title');
const toast = document.getElementById('toast');
const titles = { dashboard: 'Genel bakış', models: 'Modeller', contact: 'İletişim bilgileri', settings: 'Ayarlar' };

function showToast(message) {
    toast.textContent = message;
    toast.classList.add('show');
    window.clearTimeout(showToast.timeout);
    showToast.timeout = window.setTimeout(() => toast.classList.remove('show'), 2200);
}

function openView(viewName) {
    navItems.forEach(item => item.classList.toggle('active', item.dataset.view === viewName));
    views.forEach(view => view.classList.toggle('active', view.dataset.viewPanel === viewName));
    viewTitle.textContent = titles[viewName] || titles.dashboard;
}

navItems.forEach(item => item.addEventListener('click', () => openView(item.dataset.view)));
document.querySelectorAll('[data-open-view]').forEach(button => button.addEventListener('click', () => openView(button.dataset.openView)));

autoLoadModels();

function autoLoadModels() {
    const list = document.getElementById('model-list');
    const stored = JSON.parse(localStorage.getItem('karvel-demo-models') || '[]');
    const defaults = [
        ['Model 1', 'Erkek'], ['Model 2', 'Erkek'], ['Model 3', 'Erkek'],
        ['Model 4', 'Kadın'], ['Model 5', 'Kadın'], ['Model 6', 'Kadın']
    ];
    list.innerHTML = '';
    [...defaults, ...stored].forEach((model, index) => {
        const row = document.createElement('div');
        row.className = 'model-row';
        row.innerHTML = `<div class="model-thumb"></div><strong>${model.name || model[0]}</strong><small>${model.category || model[1]}</small>${index >= defaults.length ? '<button class="delete-model" type="button" aria-label="Modeli sil"><i class="fa-solid fa-trash"></i></button>' : ''}`;
        const deleteButton = row.querySelector('.delete-model');
        if (deleteButton) deleteButton.addEventListener('click', () => {
            stored.splice(index - defaults.length, 1);
            localStorage.setItem('karvel-demo-models', JSON.stringify(stored));
            autoLoadModels();
            showToast('Model silindi.');
        });
        list.appendChild(row);
    });
    document.getElementById('model-count').textContent = defaults.length + stored.length;
}

document.getElementById('model-form').addEventListener('submit', event => {
    event.preventDefault();
    const stored = JSON.parse(localStorage.getItem('karvel-demo-models') || '[]');
    stored.push({ name: document.getElementById('model-name').value, category: document.getElementById('model-category').value });
    localStorage.setItem('karvel-demo-models', JSON.stringify(stored));
    event.target.reset();
    autoLoadModels();
    showToast('Model demo olarak kaydedildi.');
});

document.getElementById('cancel-model').addEventListener('click', () => document.getElementById('model-form').reset());
document.getElementById('new-model-button').addEventListener('click', () => document.getElementById('model-name').focus());

document.getElementById('contact-form').addEventListener('submit', event => {
    event.preventDefault();
    localStorage.setItem('karvel-demo-contact', JSON.stringify({ phone: document.getElementById('admin-phone').value, email: document.getElementById('admin-email').value, address: document.getElementById('admin-address').value }));
    showToast('İletişim bilgileri demo olarak kaydedildi.');
});

document.getElementById('admin-theme').addEventListener('click', () => {
    const dark = document.body.classList.toggle('admin-dark');
    document.getElementById('theme-status').textContent = dark ? 'Koyu' : 'Açık';
    showToast('Panel teması değiştirildi.');
});
document.getElementById('admin-language').addEventListener('click', () => showToast('Dil ayarı demo panelinde hazır.'));
